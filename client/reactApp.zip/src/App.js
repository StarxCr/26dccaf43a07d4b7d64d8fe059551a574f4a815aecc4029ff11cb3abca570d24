import './App.css';
import Navigation from './components/Nav/Navigation';
import {FormPage} from './components/MainView/FormPage';
import ListingPage from './components/MainView/ListingPage';
import Statistics from './components/MainView/Statistics';
function App() {
  return (
    <div className="App">
      <Navigation>Header</Navigation>
      {/* <FormPage/> */}
      <Statistics/>
    </div>
  );
}

export default App;
