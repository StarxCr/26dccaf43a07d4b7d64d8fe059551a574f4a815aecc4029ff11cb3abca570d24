import React from "react";
import * as s from "./Nav.style";
const Navigation = (props) => {
  const {
    navItems = [
      {
        name: "Home", path: "/",
      },
      {
        name: "Create", path: "/",
      },
      { name: "Statictics", path: "/" },
    ],
  } = props;
  const connected = true;
  const navItemsJSX = navItems.map((item, i) => (
    <s.NavItem key={i} href={item.path}>{item.name}</s.NavItem>
  ));
  return (
    <s.NavContainer>
        <h3>This is logo</h3>
      <s.Nav>
        {navItemsJSX}
        <s.ConnectButton>{connected ? 'address' : 'Connect'}</s.ConnectButton>
      </s.Nav>
    </s.NavContainer>
  );
};

export default Navigation;
