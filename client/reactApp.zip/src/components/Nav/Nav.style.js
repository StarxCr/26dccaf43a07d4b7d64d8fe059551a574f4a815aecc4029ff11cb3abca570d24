import styled from "styled-components";

export const Logo = styled.img`
height: 80%;
order: 0;
`
export const NavContainer = styled.div`
box-sizing: border-box;
display: flex;
align-items:center;
justify-content: center;
height: 10vh;
width: 100vw;
background: #3C3C3C;
padding: .5rem 6rem;
padding-block: 1rem;
&::before{
    content:'';
    order:1;
    margin-left: 5rem;
    background: #DDDDDD;
    border-radius: 1rem;
    height: 5%;
    width: 30%;

}
`

export const Nav = styled.div`
display: flex;
order: 2;
max-height: 80%;
align-items: center;
justify-content: space-between;
margin-left: -2rem;
padding: 1rem 2.5rem;
border-radius: 2rem;
background: rgba(138, 137, 137, 0.4);
backdrop-filter: blur(3px);
`
export const NavItem = styled.a`
font-size: 1rem;
color: white;
letter-spacing: 1px;
text-decoration: none;
margin-inline: .75rem;
cursor: pointer;
`
export const ConnectButton = styled.button`
height: 100%;
letter-spacing: 1px;
outline: none;
background: #8000FF;
color: #FFFFFF;
border-radius: 2rem;
border: none;
font-size: 1rem;
padding: .25em .75em;
margin-left: 4rem;
margin-right: .5rem;
cursor: pointer;
padding: .75em 1.25em;
`