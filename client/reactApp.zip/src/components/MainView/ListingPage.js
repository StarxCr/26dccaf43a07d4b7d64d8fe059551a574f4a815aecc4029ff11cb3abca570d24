import React from 'react'
import * as s from './Pages.styles';

const ListingPage = () => {
  // fetch('/uploads/1.json').then(res=>res.json()).then(data =>console.log(data))
  return (
    <s.PageSection>
      <s.MainContainer>
          <s.Title>Look at me ima title</s.Title>
      </s.MainContainer>
    </s.PageSection>
    
  
  )
}

export default ListingPage