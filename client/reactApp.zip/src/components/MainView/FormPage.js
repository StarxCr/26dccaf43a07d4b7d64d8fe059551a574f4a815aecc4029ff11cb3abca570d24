import React, { useEffect, useRef, useState } from "react";
import * as s from "./Pages.styles";
import { Trait } from "./Traits";

async function getData(data, _attributes =[]) {
  const nftData = {
    name: data.name,
    description: data.description,
    supply: data.supply,
    attributes: _attributes
  }
  const jsonData = JSON.stringify(nftData);
  const url = '/uploads';
  const options = {
    method: 'POST',
    mode: 'cors',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'},
      body: jsonData
  };
  const result = await fetch(url, options)
    .then(res=>res.json())
    .then(data=>console.log(data))
  // console.log(JSON.stringify(nftData));
  // return fetch(url, options).then(res=>res.body).then(data=>console.log(data))
  
};
export const getAttributeList = (typeRef, valueRef) => {
  const attributesList = [];
  for(let i= 0; i < typeRef.current.length; i++){
    let tempData = {
      trait_type: typeRef.current[i].value,
      value: valueRef.current[i].value,
    }
    attributesList.push(tempData);
  }
  //console.log(attributesList)
  return attributesList
}

export const FormPage = (props) => {
  const {
    colors = {
      textColor: "black",
      textColorHower: "white",
      bgColor: "lightgrey",
      bgColorHower: '#525252',
    },
  } = props;
  /*-----------States-------*/
  const [state, setState] = useState({
    name: "",
    description: "",
    supply: "",
  });
  /*-----------Refs-------*/
  
  const traitRef = useRef([]);
  const valueRef = useRef([]);
  
  /*-----------Effects-------*/
  const [traits,setTraits] = useState([1, 1, 1]);
  useEffect(()=>{
    traitRef.current = traitRef.current.slice(0, traits.length)
    valueRef.current = valueRef.current.slice(0, traits.length)
  }, [traits]);
  
  
  const traitsJSX = traits.map((item, i )=>{
    return <Trait key = {i} ref1={el => traitRef.current[i]= el} ref2={el2 => valueRef.current[i]= el2}/>
  })
  const handleChange = (e) => {
    const value = e.target.value;
    setState({
      ...state,
      [e.target.name]: value,
    });
  };

  const addTrait = () =>{
    const newList = [...traits, 1];
    setTraits(newList);
    
  };
  const deleteTrait = () =>{
    let newList = []
    for(let i=0;i<traits.length - 1; i++){
      newList.push(traits[i])
    }
    setTraits(newList);
    
  }
  return (
    <s.PageSection>
        <s.Title>Fill the form</s.Title>
      <s.MainContainer>
    <s.SubContainer>
        <s.desc>Enter the name:</s.desc>
        <s.TextInput
          textColor={colors.textColor}
          bgColor={colors.bgColor}
          placeholder="NFT name"
          type="text"
          name="name"
          value={state.name}
          onChange={handleChange}
        ></s.TextInput>
  <s.desc>Add a detailed description of your NFT:</s.desc>
        <s.DescInput
        maxLength={140}
          textColor={colors.textColor}
          bgColor={colors.bgColor}
          type="text"
          name="description"
          placeholder="Provide a detailed description of your NFT"
          value={state.description}
          onChange={handleChange}
        ></s.DescInput>
  <s.desc>Add a total number of NFTs:</s.desc>

        <s.TextInput
          textColor={colors.textColor}
          bgColor={colors.bgColor}
          type="number"
          min="1"
          name="supply"
          placeholder="Supply"
          value={state.supply}
          onChange={handleChange}
        ></s.TextInput>
  <s.desc>Add up to 5 traits and their values:</s.desc>
      <div style={{display: 'flex'}}>
          <div>

        {traitsJSX}
          </div>
        <s.AddTraitBtn onClick={()=>addTrait()}></s.AddTraitBtn>
      </div>
         
        {/* <s.Button onClick={()=>getAttributeList(traitRef, valueRef)}>log type/values</s.Button> */}
        {/* <s.Button onClick={()=>console.log(traitRef.current[1].value)}>Log traitRef</s.Button> */}
        {/* <s.Button onClick={()=>getData(state, getAttributeList(traitRef, valueRef))}>Next</s.Button> */}
        <s.Button 
        bgColor='transparent'
        outline="#8000FF"
        color='white'>Назад</s.Button>

          
          </s.SubContainer>
        <s.SubContainer>
    <s.ImagePreview></s.ImagePreview>
  <s.desc style={{textAlign:'center', alingSelf: 'center', letterSpacing: '1px', width: '100%'}}>Upload media files with max size of xxMB
(PNG, JPG, GIF, MP3, MP4)</s.desc>
        <s.Button
        bgColor='#8000FF'
        color='white'
        outline='transparent'
        onClick={()=>getData(state, getAttributeList(traitRef, valueRef))}>Продолжить</s.Button>
        {/* <s.Button onClick={()=>deleteTrait()}>Delete trait: {traits.length}</s.Button> */}

        </s.SubContainer>
      </s.MainContainer>
    </s.PageSection>
  );
};

// export default FormPage;
